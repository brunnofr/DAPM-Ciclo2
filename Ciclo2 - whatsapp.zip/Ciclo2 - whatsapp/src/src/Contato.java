package src;

/**
 *
 * @author Brunno Freitas
 */
public class Contato {
    private String nome;
    
    public Contato(String nome){
        this.nome = nome;
    }
    
    public String getNome(){
        return this.nome;
    }
}
