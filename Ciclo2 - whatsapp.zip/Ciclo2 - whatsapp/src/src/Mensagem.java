package src;

/**
 *
 * @author Brunno Freitas
 */
public class Mensagem {
    private String texto;
    
    public Mensagem(String texto){
        this.texto = texto;
    }
    
    public String getMensagem(){
        return this.texto;
    }
}
